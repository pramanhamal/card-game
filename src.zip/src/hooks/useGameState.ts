import { useState } from 'react';
import { GameState, Card, PlayerId } from '../types/spades';
import { initializeGame, playCard as logicPlay, evaluateTrick } from '../utils/gameLogic';

export function useGameState() {
  const [state, setState] = useState<GameState>(initializeGame());

  function startGame() {
    setState(initializeGame());
  }

  function playCard(player: PlayerId, card: Card) {
    setState(prev => {
      const afterPlay = logicPlay(prev, player, card);
      const allPlayed = Object.values(afterPlay.trick).every(c => c !== null);
      return allPlayed ? evaluateTrick(afterPlay) : afterPlay;
    });
  }

  return { state, startGame, playCard };
}