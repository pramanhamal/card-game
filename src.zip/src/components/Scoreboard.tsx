import React from 'react';
import { PlayerId } from '../types/spades';

interface ScoreboardProps {
  scores: Record<PlayerId, number>;
}

export const Scoreboard: React.FC<ScoreboardProps> = ({ scores }) => (
  <div className="scoreboard mt-4">
    <h3>Scores</h3>
    <ul>
      {Object.entries(scores).map(([p, s]) => (
        <li key={p} className="capitalize">
          {p}: {s}
        </li>
      ))}
    </ul>
  </div>
);