export type Suit = 'spades' | 'hearts' | 'diamonds' | 'clubs';
export type Rank = 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 'J' | 'Q' | 'K' | 'A';

export interface Card {
  suit: Suit;
  rank: Rank;
}

export type PlayerId = 'north' | 'east' | 'south' | 'west';

export interface GameState {
  deck: Card[];
  hands: Record<PlayerId, Card[]>;
  trick: Record<PlayerId, Card | null>;
  tricksWon: Record<PlayerId, Card[][]>;
  scores: Record<PlayerId, number>;
  turn: PlayerId;
}