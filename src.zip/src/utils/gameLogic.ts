import { Card, Suit, Rank, PlayerId, GameState } from '../types/spades';

const suits: Suit[] = ['spades', 'hearts', 'diamonds', 'clubs'];
const ranks: Rank[] = [2, 3, 4, 5, 6, 7, 8, 9, 10, 'J', 'Q', 'K', 'A'];

export function createDeck(): Card[] {
  return suits.flatMap(suit => ranks.map(rank => ({ suit, rank })));
}

export function shuffle<T>(array: T[]): T[] {
  const a = [...array];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function deal(cards: Card[]): Record<PlayerId, Card[]> {
  const hands: Record<PlayerId, Card[]> = {
    north: [], east: [], south: [], west: []
  };
  cards.forEach((card, idx) => {
    const player: PlayerId = ['north','east','south','west'][idx % 4] as PlayerId;
    hands[player].push(card);
  });
  return hands;
}

export function initializeGame(): GameState {
  const deck = shuffle(createDeck());
  const hands = deal(deck.slice(0, 52));
  return {
    deck,
    hands,
    trick: { north: null, east: null, south: null, west: null },
    tricksWon: { north: [], east: [], south: [], west: [] },
    scores: { north: 0, east: 0, south: 0, west: 0 },
    turn: 'north'
  };
}

export function playCard(state: GameState, player: PlayerId, card: Card): GameState {
  // Remove from hand
  const hand = state.hands[player].filter(c => !(c.suit === card.suit && c.rank === card.rank));
  const trick = { ...state.trick, [player]: card };
  return { ...state, hands: { ...state.hands, [player]: hand }, trick };
}

export function evaluateTrick(state: GameState): GameState {
  // Simplified: first non-null wins
  const played = Object.entries(state.trick).filter(([, c]) => c) as [PlayerId, Card][];
  const winner = played[0][0];
  const tricksWon = { ...state.tricksWon, [winner]: [...state.tricksWon[winner], played.map(([,c]) => c)] };
  const scores = { ...state.scores, [winner]: state.scores[winner] + 1 };
  return {
    ...state,
    trick: { north: null, east: null, south: null, west: null },
    tricksWon,
    scores,
    turn: winner
  };
}