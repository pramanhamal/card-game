import React from 'react';
import { useGameState } from './hooks/useGameState';
import { GameBoard } from './components/GameBoard';
import { Scoreboard } from './components/Scoreboard';

const App: React.FC = () => {
  const { state, startGame, playCard } = useGameState();

  return (
    <div className="app p-4">
      <header className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-bold">Spades Game</h1>
        <button onClick={startGame} className="btn">New Game</button>
      </header>
      <GameBoard state={state} playCard={playCard} />
      <Scoreboard scores={state.scores} />
    </div>
  );
};

export default App;